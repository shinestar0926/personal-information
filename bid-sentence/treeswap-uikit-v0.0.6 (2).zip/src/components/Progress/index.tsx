export { default as Progress } from "./Progress";
export type { ProgressProps } from "./types";
