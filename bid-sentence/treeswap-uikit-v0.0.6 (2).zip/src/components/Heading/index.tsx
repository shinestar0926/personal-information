export { default as Heading } from "./Heading";
export type { HeadingProps, Sizes as HeadingSizes, Tags as HeadingTags } from "./types";
