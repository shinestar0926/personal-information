import React, { useEffect, useCallback, useState } from 'react'
import { Route, useRouteMatch } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import styled from 'styled-components'
import BigNumber from 'bignumber.js'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { provider } from 'web3-core'
import { Image, Heading } from '@pancakeswap-libs/uikit'
import { BLOCKS_PER_YEAR, CAKE_PER_BLOCK, CAKE_POOL_PID } from 'config'
import FlexLayout from 'components/layout/Flex'
import Page from 'components/layout/Page'
import { useFarms, usePriceBnbBusd, usePriceCakeBusd, usePriceTreeBusd,useFarmFromPid } from 'state/hooks'
import useRefresh from 'hooks/useRefresh'
import { fetchFarmUserDataAsync } from 'state/actions'
import { QuoteToken } from 'config/constants/types'
import useI18n from 'hooks/useI18n'
import FarmCard, { FarmWithStakedValue } from './components/FarmCard/FarmCard'
import FarmTabButtons from './components/FarmTabButtons'
import Divider from './components/Divider'

const Footer = styled.div`
  background-image: url(/images/footerbg.svg);
  background-position: bottom;
  background-repeat-x: repeat;
  background-repeat-y: no-repeat;
  padding-bottom: 17%;
  background-size: 50%;
`

export interface FarmsProps{
  tokenMode?: boolean
}

const Farms: React.FC<FarmsProps> = (farmsProps) => {
  const { path } = useRouteMatch()
  const TranslateString = useI18n()
  const farmsLP = useFarms()
  const cakePrice = usePriceCakeBusd()
  const bnbPrice = usePriceBnbBusd()
  const treePrice = usePriceTreeBusd()
  const { account, ethereum }: { account: string; ethereum: provider } = useWallet()
  const {tokenMode} = farmsProps;

  const dispatch = useDispatch()
  const { fastRefresh } = useRefresh()
  useEffect(() => {
    if (account) {
      dispatch(fetchFarmUserDataAsync(account))
    }
  }, [account, dispatch, fastRefresh])

  const [stakedOnly, setStakedOnly] = useState(false)

  const activeFarms = farmsLP.filter((farm) => !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X')
  const inactiveFarms = farmsLP.filter((farm) => !!farm.isTokenOnly === !!tokenMode && farm.multiplier === '0X')
  const partnerFarms = farmsLP.filter((farm) => !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X' && farm.isPartner === true)
  const seedFarms = farmsLP.filter((farm) => !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X' && farm.lpSymbol.includes('SEED'))
  const treeFarms = farmsLP.filter((farm) => !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X' && farm.lpSymbol.includes('TREE'))
  
  const stakedOnlyFarms = activeFarms.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )
  const stakedOnlyPartnerFarms = partnerFarms.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )
  const stakedOnlySeedFarms = seedFarms.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )
  const stakedOnlyTreeFarms = treeFarms.filter(
    (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
  )

  const seedcakeFarm = useFarmFromPid(15)
  const seedcakePrice = new BigNumber(seedcakeFarm.tokenPriceVsQuote)
  const cakeTokenPrice = seedcakePrice.times(cakePrice)

  const treeslimeFarm = useFarmFromPid(16)
  const treeslimePrice = new BigNumber(treeslimeFarm.tokenPriceVsQuote)
  const slimetreeTokenPrice = treeslimePrice.times(cakePrice)

  const seedslimeFarm = useFarmFromPid(17)
  const seedslimePrice = new BigNumber(seedslimeFarm.tokenPriceVsQuote)
  const slimeTokenPrice = seedslimePrice.times(cakePrice)

  // /!\ This function will be removed soon
  // This function compute the APY for each farm and will be replaced when we have a reliable API
  // to retrieve assets prices against USD
  const farmsList = useCallback(
    (farmsToDisplay, removed: boolean) => {
      // const cakePriceVsBNB = new BigNumber(farmsLP.find((farm) => farm.pid === CAKE_POOL_PID)?.tokenPriceVsQuote || 0)
      const farmsToDisplayWithAPY: FarmWithStakedValue[] = farmsToDisplay.map((farm) => {
        // if (!farm.tokenAmount || !farm.lpTotalInQuoteToken || !farm.lpTotalInQuoteToken) {
        //   return farm
        // }
        const cakeRewardPerBlock = new BigNumber(farm.treePerBlock || 1).times(new BigNumber(farm.poolWeight)) .div(new BigNumber(10).pow(18))
        const cakeRewardPerYear = cakeRewardPerBlock.times(BLOCKS_PER_YEAR)

        let apy = cakePrice.times(cakeRewardPerYear);

        let totalValue = new BigNumber(farm.lpTotalInQuoteToken || 0);

        if (farm.quoteTokenSymbol === QuoteToken.BNB) {
          totalValue = totalValue.times(bnbPrice);
        }

        if(totalValue.comparedTo(0) > 0){
          apy = apy.div(totalValue);
        }

        if(farm.lpSymbol === 'SEED-TREE LP') {
          totalValue = totalValue.times(treePrice)
          apy = treePrice.times(cakeRewardPerYear).div(totalValue)
        }

        if(farm.lpSymbol === 'SEED-CAKE LP') {
          totalValue = totalValue.times(cakeTokenPrice)
          apy = cakeTokenPrice.times(cakeRewardPerYear).div(totalValue)
        }

        if(farm.lpSymbol === 'TREE-SLIME LP') {
          totalValue = totalValue.times(slimetreeTokenPrice).times(treePrice).div(cakePrice)
          apy = slimetreeTokenPrice.times(cakeRewardPerYear).div(totalValue)
        }

        if(farm.lpSymbol === 'SEED-SLIME LP') {
          totalValue = totalValue.times(slimeTokenPrice)
          apy = slimeTokenPrice.times(cakeRewardPerYear).div(totalValue)
        }

        return { ...farm, apy }
      })
      return farmsToDisplayWithAPY.map((farm) => (
        <>
        {(farm.pid !== 11) &&
          <FarmCard
            key={farm.pid}
            farm={farm}
            removed={removed}
            bnbPrice={bnbPrice}
            cakePrice={cakePrice}
            treePrice={treePrice}
            ethereum={ethereum}
            account={account}
          />
        }
        </>
      ))
    },
    [bnbPrice, account, cakePrice, ethereum, treePrice, cakeTokenPrice, slimeTokenPrice, slimetreeTokenPrice],
  )

  return (
    <div>
      <Page>
        <Heading as="h1" size="lg" color="primary" mb="50px" style={{ textAlign: 'center' }}>
          {
            tokenMode ?
              TranslateString(10002, 'Stake tokens to earn SEED')
              :
            TranslateString(320, 'Stake LP tokens to earn SEED')
          }
        </Heading>
        <Heading as="h2" color="secondary" mb="50px" style={{ textAlign: 'center' }}>
          {TranslateString(10000, 'Part of deposit fees will be used to plant real trees around the world')}
        </Heading>
        <FarmTabButtons stakedOnly={stakedOnly} setStakedOnly={setStakedOnly}/>
        <div>
          <Divider />
          <FlexLayout>
            <Route exact path={`${path}`}>
              {stakedOnly ? farmsList(stakedOnlyFarms, false) : farmsList(activeFarms, false)}
            </Route>
            <Route exact path={`${path}/seed`}>
              {stakedOnly ? farmsList(stakedOnlySeedFarms, false) : farmsList(seedFarms, false)}
            </Route>
            <Route exact path={`${path}/tree`}>
              {stakedOnly ? farmsList(stakedOnlyTreeFarms, false) : farmsList(treeFarms, false)}
            </Route>
            <Route exact path={`${path}/partner`}>
              {stakedOnly ? farmsList(stakedOnlyPartnerFarms, false) : farmsList(partnerFarms, false)}
            </Route>
            <Route exact path={`${path}/history`}>
              {farmsList(inactiveFarms, true)}
            </Route>
          </FlexLayout>
        </div>
        {/* <Image src="/images/egg/8.png" alt="illustration" width={1352} height={587} responsive /> */}
      </Page>
      <Footer />
    </div>
  )
}

export default Farms
