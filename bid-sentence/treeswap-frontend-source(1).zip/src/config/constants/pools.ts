import { PoolConfig, QuoteToken, PoolCategory } from './types'

const pools: PoolConfig[] = [
  {
    sousId:1,
    tokenName: 'TREE',
    stakingTokenName: QuoteToken.SEED,
    stakingTokenAddress: '0x40B34cC972908060D6d527276e17c105d224559d',
    contractAddress: {
      97: '0x9336fA00EbB103CB6F4E974eD793c43E25C713F6',
      56: '0xB6BD117Fea70e7eE5C114BCEa2ae256a141Cad95',
      // 56: '0xF69C786380886d36C8Aa92d6d6a3Ded168e79616',
    },
    poolCategory: PoolCategory.CORE,
    projectLink: 'https://www.binance.org/',
    harvest: true, isFinished: false,
    tokenPerBlock: '0.001157407407407407',
    sortOrder: 1,
    tokenDecimals: 18,
    startBlock: 6304385,
    endBlock: 7168385,
    withwithdrawFee:false,
    withdrawFee:0,
    slimeRounding:6
  },
]

export default pools
