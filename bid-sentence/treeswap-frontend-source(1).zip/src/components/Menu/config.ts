import { MenuEntry } from '@pancakeswap-libs/uikit'

const config: MenuEntry[] = [
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: '/',
  },
  {
    label: 'Buy TREE',
    icon: 'TREEIcon',
    href: 'https://exchange.treedefi.com/#/swap?outputCurrency=0xf0fcd737fce18f95621cc7841ebe0ea6efccf77e',
  },
  {
    label: 'Buy SEED',
    icon: 'SEEDIcon',
    href: 'https://exchange.treedefi.com/#/swap?outputCurrency=0x40B34cC972908060D6d527276e17c105d224559d',
  },
  {
    label: 'Trade',
    icon: 'TradeIcon',
    items: [
      {
        label: 'Exchange',
        href: 'https://exchange.treedefi.com/',
      },
      {
        label: 'Liquidity',
        href: 'https://exchange.treedefi.com/#/pool',
      },
    ],
  },
  {
    label: 'Farms',
    icon: 'FarmIcon',
    href: '/farms',
  },
  {
    label: 'Staking',
    icon: 'PoolIcon',
    href: '/staking',
  },
   {
      label: 'Pools',
      icon: 'IfoIcon',
      href: '/launch-pools',
   },
  {
    label: 'Lottery',
    icon: 'TicketIcon',
    href: '/lottery',
  },
  {
    label: 'Games',
    icon: 'NftIcon',
    items: [
      {
        label: 'King of The Forest',
        href: '/game',
      },
    ],
  },
  {
    label: 'Info',
    icon: 'InfoIcon',
    items: [
      {
        label: 'Project Info',
        href: 'https://treedefi.com/',
      },
      {
        label: 'Litepaper',
        href: 'http://litepaper.treedefi.com/',
      },
      {
        label: 'Donation Vault',
        href: 'https://donation.treedefi.com/',
      },
      {
        label: 'Marketing Vault',
        href: 'https://treedefi.com/mav/',
      },
      {
        label: 'TechRate Audit',
        href: 'audit/TechRate_Audit.pdf',
      },
    ],
  },
  {
    label: 'More',
    icon: 'MoreIcon',
    items: [
      {
        label: 'Docs',
        href: 'https://docs.treedefi.com/',
      },
      {
        label: 'Github',
        href: 'https://github.com/treedefi',
      },
      {
        label: 'Medium',
        href: 'https://treedefi.medium.com/',
      },
    ],
  },
  // {
  //   label: 'Partnerships/IFO',
  //   icon: 'GooseIcon',
  //   href: 'https://docs.google.com/forms/d/e/1FAIpQLSe7ycrw8Dq4C5Vjc9WNlRtTxEhFDB1Ny6jlAByZ2Y6qBo7SKg/viewform?usp=sf_link',
  // },
  // {
  //   label: 'Audit by Hacken',
  //   icon: 'AuditIcon',
  //   href: 'https://www.goosedefi.com/files/hackenAudit.pdf',
  // },
  // {
  //   label: 'Audit by CertiK',
  //   icon: 'AuditIcon',
  //   href: 'https://certik.org/projects/goose-finance',
  // },
]

export default config
